# Bloque 1 — Experiencia del alumno

Implementa estas funcionalidades en la plataforma Política Digital (Next.js App Router + Firebase + Tailwind + UI Kit propio).

---

## 1. Diario de aprendizaje

Al terminar cada lección, mostrar un modal/sección opcional:
"¿Qué aprendiste hoy? ¿Cómo lo aplicarías en tu trabajo?"

- Dos campos de texto corto (máx 200 chars cada uno)
- Botón "Guardar en mi diario" y "Saltar por ahora"
- Guardar en Firestore: /users/{userId}/journal/{lessonId}
- Al final del curso: página /mi-diario con todas las entradas ordenadas por módulo
- Exportar el diario completo como PDF (usar jspdf)
- El bot puede leer el diario para personalizar sus respuestas

### Archivos:
- components/journal/JournalPrompt.tsx — modal post-lección
- app/mi-diario/page.tsx — vista completa del diario
- lib/services/journal.ts — CRUD Firestore

---

## 2. Carta al yo futuro

Al registrarse por primera vez (después del diagnóstico inicial):
Modal: "Escríbete una carta sobre lo que esperas lograr al terminar este programa."

- Textarea de máx 500 caracteres
- Botón "Guardar mi carta" y "Prefiero no escribirla"
- Guardar en Firestore: /users/{userId}/futureLetter
- Al completar el 100% del curso: mostrar la carta original + resumen del bot comparando promesas vs logros reales
- Email automático (si tiene email) recordándole la carta

### Archivos:
- components/onboarding/FutureLetter.tsx
- app/mi-carta/page.tsx — vista de la carta al completar
- lib/services/futureLetter.ts

---

## 3. Check-in de bienestar

Al iniciar sesión cada día, el bot pregunta una vez:
"Hola [nombre], ¿cómo estás hoy?"

Opciones rápidas (chips):
- 🟢 "Listo para aprender"
- 🟡 "Más o menos, pero aquí estoy"
- 🔴 "Estresado/a hoy"

Lógica según respuesta:
- Verde: abrir el dashboard normalmente
- Amarillo: bot sugiere lección más corta o repaso
- Rojo: bot dice "Entiendo. Hoy puedes hacer solo 5 min o volver mañana. ¿Qué prefieres?" + opciones

Guardar estado diario en Firestore: /users/{userId}/wellbeing/{fecha}
No mostrar el check-in si ya se respondió hoy.

### Archivos:
- components/wellbeing/DailyCheckin.tsx
- lib/services/wellbeing.ts
- Integrar en app/(app)/inicio/page.tsx

---

## 4. Música de fondo para estudiar

Toggle en la barra superior o sidebar: "🎵 Modo foco"

Al activar: embed de playlist lo-fi de YouTube Music o Spotify
- Usar YouTube iframe embed con playlist pública de lo-fi
- El toggle guarda preferencia en localStorage
- Volumen ajustable con slider discreto
- Se pausa automáticamente si el alumno navega fuera de la lección

### Archivos:
- components/ui/MusicPlayer.tsx
- Integrar toggle en components/layout/Sidebar.tsx o AppShell.tsx

---

## 5. Gamificación completa

### Puntos:
- Completar lección: +10 puntos
- Completar módulo: +50 puntos
- Responder en comunidad: +5 puntos
- Racha de 3 días: +20 puntos bonus
- Aprobar quiz primera vez: +30 puntos

### Badges (calcular automáticamente):
| Badge | Condición |
|-------|-----------|
| Primera lección | 1 lección completada |
| Racha de 3 días | 3 días consecutivos |
| Racha de 7 días | 7 días consecutivos |
| Módulo completo | Todos los módulos de un curso |
| Mitad del camino | 50% completado |
| Contribuidor | 5 respuestas en comunidad |
| Mentor | Completó el programa y ayudó a otro alumno |
| Certificado | 100% completado + quiz aprobado |

### Misiones semanales:
Cada lunes el bot propone 3 misiones opcionales:
- Ej: "Completa 2 lecciones esta semana"
- Ej: "Comenta en la comunidad 1 vez"
- Ej: "Haz el quiz del módulo actual"
Al completar misión: badge temporal + puntos bonus

### Leaderboard semanal:
- Ranking por puntos de la semana (no acumulado)
- Solo visible si hay más de 5 alumnos activos
- Se resetea cada lunes
- Mostrar posición del alumno aunque no esté en top 10

### Escape room básico (Bloque 6 lo expande):
- Un módulo especial tipo juego donde el alumno desbloquea pistas resolviendo preguntas
- Usar branching con el bot Claude

### Archivos:
- lib/services/gamification.ts — calcular puntos y badges
- components/gamification/BadgeDisplay.tsx
- components/gamification/Leaderboard.tsx
- components/gamification/WeeklyMissions.tsx
- app/mis-logros/page.tsx — vista de badges y puntos

---

## 6. Mapa de impacto personal

Visualización que conecta el aprendizaje con el trabajo real del alumno.

Basado en el diagnóstico inicial (institución, cargo, desafío):
"Completaste el módulo de Gestión del Cambio — esto impacta directamente tu desafío: Resistencia al cambio en mi equipo."

- Mostrar en el dashboard como card dinámica
- Se actualiza con cada módulo completado
- El bot genera el texto de conexión usando Claude API

### Archivos:
- components/dashboard/ImpactMap.tsx
- lib/services/impactMap.ts — genera texto con Claude

---

## 7. Zona de descanso

Entre módulos completados, mostrar contenido opcional liviano:
- Podcast corto de 3 min (embed de Spotify o iframe)
- Dato curioso de innovación pública en el mundo
- Artículo de opinión breve (link externo curado)
- Quote inspiracional de innovadores del sector público

El admin puede agregar contenido a la zona de descanso desde /admin/zona-descanso

### Archivos:
- components/learning/BreakZone.tsx
- app/admin/zona-descanso/page.tsx
- lib/services/breakContent.ts

---

## Restricciones:
- En modo demo: mostrar datos de ejemplo, no guardar en Firestore
- Todas las funciones son opcionales para el alumno (no forzar)
- No romper funcionalidades existentes
- Usar UI Kit existente
- Mobile-first en todos los componentes
