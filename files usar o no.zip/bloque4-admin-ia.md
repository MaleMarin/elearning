# Bloque 4 — Admin con IA

Herramientas de generación de contenido con IA para el administrador.

---

## 1. PDF/PPT → Lección automática

El admin sube un documento y la IA genera una lección estructurada.

### Flujo:
1. En /admin/cursos/[id]/lecciones/nueva: botón "Generar desde archivo"
2. Admin sube PDF o PPT (máx 10MB)
3. Extraer texto del archivo:
   - PDF: usar pdf-parse (`npm install pdf-parse`)
   - PPT: convertir a texto con mammoth o similar
4. Enviar texto a Claude API con prompt:
   "Eres un diseñador instruccional experto. Convierte este contenido en una lección e-learning.
    Genera: título, objetivo de aprendizaje (verbo Bloom), 3-5 bloques de contenido, 
    3 preguntas de quiz con respuesta correcta y explicación.
    Formato JSON estricto: { title, objective, blocks[], quiz[] }"
5. Mostrar preview editable antes de guardar
6. Admin puede editar cada bloque antes de publicar

### Archivos:
- app/admin/cursos/[id]/lecciones/generar/page.tsx
- components/admin/AILessonGenerator.tsx
- app/api/admin/generate-lesson/route.ts
- lib/services/documentParser.ts

---

## 2. YouTube URL → Microlección

El admin pega una URL de YouTube y la IA genera una microlección.

### Flujo:
1. Admin pega URL de YouTube en /admin/lecciones/nueva
2. Obtener transcripción del video usando YouTube Data API o caption scraping
3. Enviar transcripción a Claude:
   "Resume este video en una microlección de máx 5 min de lectura.
    Genera: título, 3 conceptos clave, resumen en 3 párrafos, 2 preguntas de reflexión.
    Incluir timestamp del video donde aparece cada concepto."
4. La lección generada incluye el video embebido + contenido generado abajo

### Archivos:
- components/admin/YouTubeImporter.tsx
- app/api/admin/import-youtube/route.ts

---

## 3. Traducción automática del curso

El admin puede traducir todo el curso a inglés o portugués con un clic.

### Flujo:
1. En /admin/cursos/[id]: botón "Traducir curso"
2. Seleccionar idioma destino: English / Português
3. Enviar todo el contenido a Claude en batches de 5 lecciones
4. Guardar traducciones en Firestore con campo `translations: { en: {}, pt: {} }`
5. El alumno puede cambiar idioma desde su perfil

### Archivos:
- app/api/admin/translate-course/route.ts
- components/admin/TranslationManager.tsx
- lib/services/translation.ts

---

## 4. Detección de contenido desactualizado

El sistema alerta cuando una lección tiene más de 6 meses sin actualizar.

### Lógica:
- Cada lección tiene `lastUpdatedAt` en Firestore
- Cron job semanal (usando Vercel Cron) revisa todas las lecciones
- Si lastUpdatedAt > 6 meses: marca lección como "Requiere revisión"
- Admin ve en /admin/cursos: badge naranja "Desactualizada" en lecciones antiguas
- Email semanal al admin con lista de lecciones a revisar
- El bot puede generar sugerencias de actualización basadas en el contenido actual

### Archivos:
- app/api/cron/check-stale-content/route.ts
- components/admin/StaleContentAlert.tsx
- lib/services/contentFreshness.ts

---

## 5. Generador de estructura de curso completo

El admin describe el curso y la IA genera toda la estructura.

### Flujo:
1. En /admin/cursos/nuevo: opción "Generar con IA"
2. Formulario: tema, audiencia, duración total, nivel
3. Claude genera:
   - Nombre y descripción del curso
   - 4-6 módulos con títulos y objetivos SMART
   - 3-4 lecciones por módulo con tipo (lectura/video/quiz)
   - Evaluación final sugerida
   - Taxonomía de Bloom por módulo
4. Admin revisa y edita antes de crear
5. Con un clic: crea toda la estructura en Firestore

### Archivos:
- app/admin/cursos/generar/page.tsx
- components/admin/CourseStructureGenerator.tsx
- app/api/admin/generate-course/route.ts

---

## Restricciones:
- Todas las generaciones IA muestran preview editable — el admin siempre aprueba antes de publicar
- En modo demo: simular respuestas IA sin llamar a Claude API real
- Límite de 10 llamadas IA por admin por día (para controlar costos)
- Los archivos subidos se guardan en Firebase Storage, no en Firestore
