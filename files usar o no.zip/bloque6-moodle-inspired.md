# Bloque 6 — Moodle-inspired + Escape room

Funcionalidades inspiradas en Moodle adaptadas al stack moderno de Política Digital.

---

## 1. Banco de preguntas + Quizzes aleatorios

Sistema donde el admin crea preguntas una vez y el sistema arma quizzes distintos.

### Modelo Firestore:
```
/question_bank/{questionId}:
  courseId, moduleId, question, type, options[], correctAnswer, explanation, difficulty, tags[]

/quizzes/{quizId}:
  courseId, title, questionCount, passingScore, timeLimit, randomize, maxAttempts

/users/{userId}/quizAttempts/{attemptId}:
  quizId, questionsServed[], answers{}, score, passed, attemptNumber, startedAt, completedAt
```

### UI alumno — QuizPlayer:
- Una pregunta a la vez con barra de progreso
- Timer opcional si tiene límite de tiempo
- Al terminar: puntaje, respuestas correctas/incorrectas con explicaciones
- Si no pasa: "Puedes intentarlo de nuevo"
- Si pasa: confetti + habilitar siguiente módulo

### UI admin:
- /admin/banco-preguntas — CRUD con filtros por módulo, dificultad, tag
- /admin/quizzes — crear quiz, seleccionar fuente de preguntas, configurar reglas
- Estadísticas: % aprobados, pregunta con más errores

### Archivos:
- app/curso/quiz/[quizId]/page.tsx
- components/quiz/QuizPlayer.tsx
- components/quiz/QuestionCard.tsx
- components/quiz/QuizResults.tsx
- app/admin/banco-preguntas/page.tsx
- app/admin/quizzes/page.tsx
- lib/services/quiz.ts

---

## 2. Peer Review — Evaluación entre pares con rúbrica

Los alumnos se evalúan entre sí usando criterios definidos por el admin.

### Flujo:
1. Admin crea actividad "Taller" con rúbrica: criterios + puntaje máximo
2. Alumno entrega trabajo (texto + archivo opcional)
3. Sistema asigna aleatoriamente 2 trabajos a evaluar
4. Alumno evalúa con la rúbrica: puntaje por criterio + feedback escrito
5. Cada alumno recibe el promedio de las evaluaciones recibidas
6. Admin puede ajustar calificaciones con justificación

### Modelo Firestore:
```
/workshops/{workshopId}: { moduleId, rubric[], deadline, reviewDeadline }
/workshops/{workshopId}/submissions/{userId}: { content, fileUrl, submittedAt }
/workshops/{workshopId}/assignments/{userId}: { reviewerOf: [userId] }
/workshops/{workshopId}/reviews/{reviewerId}_{reviewedId}: { scores{}, feedback, completedAt }
```

### Archivos:
- app/curso/taller/[workshopId]/page.tsx
- components/workshop/WorkshopSubmit.tsx
- components/workshop/PeerReviewForm.tsx
- components/workshop/RubricDisplay.tsx
- app/admin/talleres/page.tsx
- lib/services/workshop.ts

---

## 3. Libro de calificaciones

Vista global del progreso y notas de cada alumno.

### Para el alumno (/mis-calificaciones):
- Tabla: Módulo | Lección | Quiz | Taller | Estado | Nota
- Progreso visual por módulo con barras de color
- Nota final del curso (promedio ponderado configurable por admin)
- Descargar reporte personal en PDF

### Para el admin (/admin/calificaciones):
- Tabla completa: todos los alumnos × todos los ítems evaluables
- Filtrar por cohorte, módulo, estado de aprobación
- Ordenar por nota, progreso, último acceso
- Exportar a CSV
- Ver y editar calificación individual con justificación (queda en audit log)

### Archivos:
- app/mis-calificaciones/page.tsx
- app/admin/calificaciones/page.tsx
- components/grades/GradeBook.tsx
- components/grades/StudentGradeView.tsx
- lib/services/grades.ts

---

## 4. Restricciones de acceso entre módulos

Bloquear módulos hasta que el alumno complete el anterior.

### Lógica:
- Cada módulo tiene campo `requiresCompletion: string[]` en Firestore
- Al cargar /curso: verificar requisitos de cada módulo para el alumno
- Módulo bloqueado: card con candado + "Completa el módulo X para desbloquear"
- Módulo disponible: acceso normal
- Módulo completado: badge verde "Completado"

### Tipos de requisitos:
- Completar todas las lecciones del módulo anterior
- Aprobar quiz del módulo anterior (score ≥ X%)
- Ambos

### Archivos:
- lib/services/completion.ts — checkModuleAccess(userId, moduleId)
- components/curso/ModuleCard.tsx — estados bloqueado/disponible/completado
- Actualizar app/admin/cursos/[id] para configurar requisitos

---

## 5. Escape Room de aprendizaje

Módulo especial tipo juego donde el alumno desbloquea información resolviendo desafíos.

### Concepto:
"Eres un funcionario público. Hay una crisis en tu municipio. 
Necesitas aplicar innovación pública para resolverla. 
Tienes 45 minutos y 5 pistas por desbloquear."

### Estructura:
- 5 "salas" (etapas) con desafíos relacionados al contenido del curso
- Cada sala: leer un fragmento de información + responder correctamente para avanzar
- Elementos de tensión: timer visible, pistas limitadas (máx 3 por sala)
- El bot Claude actúa como "narrador" del escape room
- Al completar: badge especial "Agente de Innovación" + puntos extra

### Implementación:
- Usar branching con el bot: el alumno conversa con Claude que hace de narrador
- El estado del escape room se guarda en Firestore
- El admin puede crear escape rooms personalizados en /admin/escape-rooms

### Archivos:
- app/escape-room/[roomId]/page.tsx
- components/learning/EscapeRoomPlayer.tsx
- app/admin/escape-rooms/page.tsx
- lib/services/escapeRoom.ts

---

## Restricciones:
- En modo demo: todos los módulos disponibles sin restricciones
- El escape room es completamente opcional
- El libro de calificaciones respeta las reglas de privacidad (alumno solo ve sus notas)
- El peer review tiene moderación: el admin puede reportar evaluaciones inadecuadas
