# Bloque 5 — IA avanzada

Funcionalidades de inteligencia artificial para personalizar el aprendizaje.

---

## 1. AI Roleplay — Simulación de conversaciones

El alumno practica conversaciones difíciles con un personaje IA usando el bot Claude ya integrado.

### Escenarios disponibles (configurables por el admin):
1. "Convence a tu jefe de adoptar una innovación"
2. "Gestiona la resistencia al cambio de tu equipo"
3. "Presenta un proyecto de innovación al Ministerio"
4. "Negocia recursos para tu iniciativa"

### Flujo:
1. En la lección o módulo: botón "Practicar con un escenario"
2. El alumno elige el escenario
3. El bot adopta el personaje (ej: "Soy tu jefe, soy escéptico de los cambios...")
4. Conversación libre de 5-10 turnos
5. Al terminar: el bot sale del personaje y da feedback:
   - "Usaste bien la empatía en el turno 3"
   - "Faltó proponer una solución concreta"
   - "Sugiero que en tu próxima práctica intentes..."
6. Guardar el resumen del roleplay en Firestore

### Implementación en app/api/assistant/route.ts:
Agregar modo roleplay al system prompt:
```
Si context.mode === 'roleplay':
  "Eres [personaje]. Mantén el personaje durante toda la conversación.
   Al recibir el mensaje FINALIZAR_ROLEPLAY, sal del personaje y da feedback estructurado."
```

### Archivos:
- components/learning/RoleplayLauncher.tsx
- components/assistant/RoleplayFeedback.tsx
- lib/services/roleplay.ts

---

## 2. Micro-simulaciones de decisión

Escenarios de 2 min donde el alumno toma una decisión y ve consecuencias.

### Estructura de una micro-simulación:
```json
{
  "scenario": "Eres jefe de división. Tu equipo rechaza el nuevo sistema...",
  "options": [
    { "text": "Implementar el cambio de forma autoritaria", "outcome": "El equipo cumple pero sin compromiso. La adopción es superficial." },
    { "text": "Escuchar sus preocupaciones primero", "outcome": "Demora 2 semanas pero el equipo se compromete genuinamente." },
    { "text": "Escalar al director", "outcome": "El director apoya pero el equipo pierde confianza en ti." }
  ],
  "reflection": "¿Qué habría cambiado si hubieras involucrado al equipo desde el inicio?"
}
```

### Para el admin:
- Crear micro-simulaciones en /admin/simulaciones
- Asociarlas a módulos específicos

### Para el alumno:
- Aparecen como un bloque especial dentro de la lección
- Una opción a la vez, con animación de transición
- Al ver el resultado: reflexión automática del bot

### Archivos:
- components/learning/MicroSimulation.tsx
- app/admin/simulaciones/page.tsx
- lib/services/simulations.ts

---

## 3. Pathways adaptativos

El orden de módulos cambia según el diagnóstico inicial y el rendimiento.

### Lógica:
- Diagnóstico inicial nivel "Sin experiencia" → empezar por módulos básicos
- Diagnóstico "Experiencia práctica" → sugerir saltar intro con quiz de validación
- Alumno falla quiz 2 veces → sistema sugiere lección de refuerzo antes de continuar
- Alumno termina módulo muy rápido (< 50% del tiempo estimado) → sugerir contenido avanzado
- Mostrar en el dashboard: "Ruta recomendada para ti" con orden personalizado

### Implementación:
- Función en lib/services/adaptivePath.ts que calcula el orden sugerido
- Basada en: nivel del diagnóstico, scores de quizzes, tiempo por lección
- El alumno SIEMPRE puede ignorar la sugerencia y elegir su propio orden

### Dashboard de skills:
- Mapa visual de competencias: hexágonos o barras por competencia
- Verde = desarrollada, Amarillo = en progreso, Gris = pendiente
- Basado en los módulos completados y los objetivos de Bloom

### Archivos:
- lib/services/adaptivePath.ts
- components/dashboard/SkillsMap.tsx
- components/dashboard/RecommendedPath.tsx

---

## 4. Spaced repetition — Repaso espaciado

Preguntas de repaso aparecen 1, 7 y 30 días después de completar una lección.

### Lógica:
- Al completar una lección: guardar en Firestore las 3 fechas de repaso
- Cron job diario (Vercel Cron) que verifica qué alumnos tienen repaso pendiente
- El bot aparece proactivamente: "Hace 7 días viste X. Te hago 2 preguntas rápidas."
- Si responde bien → marcar como dominado
- Si responde mal → reagendar repaso en 3 días más

### Modelo Firestore:
```
/users/{userId}/spaced_reviews/{reviewId}:
  lessonId, questionIds[], nextReviewDate, status: "pending" | "done" | "failed"
```

### Archivos:
- lib/services/spacedRepetition.ts
- app/api/cron/send-reviews/route.ts
- components/assistant/SpacedReviewPrompt.tsx

---

## 5. Nudges automáticos inteligentes

Notificaciones contextuales basadas en comportamiento del alumno.

### Tipos de nudges:
- **Inactividad 3 días**: "Te echamos de menos. Tienes 1 lección pendiente de 5 min."
- **Módulo casi completo**: "¡Estás a 1 lección de completar el módulo 2!"
- **Racha en riesgo**: "Tu racha de 5 días termina hoy. ¿5 minutos ahora?"
- **Quiz disponible**: "Ya puedes hacer el quiz del módulo 3. ¿Lo intentamos?"
- **Compañero activo**: "Tu colega [nombre] completó 2 lecciones hoy."

### Canales:
- In-app: toast/banner al abrir la plataforma
- WhatsApp: si el alumno lo autorizó en su perfil
- Email: frecuencia según preferencia del alumno

### Archivos:
- lib/services/nudges.ts
- app/api/cron/send-nudges/route.ts
- components/ui/NudgeBanner.tsx

---

## Restricciones:
- En modo demo: mostrar los componentes con datos de ejemplo
- Los pathways adaptativos son sugerencias, nunca bloqueos
- El roleplay siempre tiene botón "Salir del escenario" visible
- El spaced repetition máximo 3 preguntas por sesión para no abrumar
