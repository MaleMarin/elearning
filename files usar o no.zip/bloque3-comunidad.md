# Bloque 3 — Comunidad extendida

Implementa el ecosistema social de aprendizaje en Política Digital.

---

## 1. Preguntas públicas en lección (Social learning básico)

Dentro de cada lección, sección al final: "Preguntas de la comunidad"

- Cualquier alumno puede hacer una pregunta pública sobre la lección
- Otros alumnos pueden responder
- El tutor puede marcar una respuesta como "oficial"
- Ordenar por: más reciente, más votada
- Notificación cuando alguien responde tu pregunta

### Modelo Firestore:
```
/questions/{lessonId}/posts/{postId}:
  userId, userName, question, createdAt, votes
  
/questions/{lessonId}/posts/{postId}/answers/{answerId}:
  userId, userName, answer, isOfficial, createdAt, votes
```

### Archivos:
- components/community/LessonQA.tsx
- lib/services/questions.ts

---

## 2. "Sabías que..." — Hallazgos del trabajo real

En cada módulo, sección: "Lo que el grupo está descubriendo"

- Alumno puede compartir: "En mi institución hacemos X diferente..."
- Formato: texto corto (máx 300 chars) + opcional: institución
- Otros pueden reaccionar con 👍 o ❤️
- El admin puede destacar los más interesantes

### Archivos:
- components/community/DidYouKnow.tsx
- lib/services/insights.ts

---

## 3. Show & Tell semanal

Espacio asincrónico semanal donde un alumno comparte cómo aplicó lo aprendido.

### Flujo:
- Cada semana el bot invita a 1-2 alumnos (rotación aleatoria) a compartir
- El alumno sube: video de 2 min (Loom URL) o texto de máx 400 chars
- Visible para toda la cohorte
- Comentarios de hasta 200 chars
- El admin puede destacar los Show & Tell más inspiradores

### Archivos:
- app/comunidad/show-and-tell/page.tsx
- components/community/ShowTellPost.tsx
- lib/services/showTell.ts

---

## 4. Modo "Aprendo con un colega"

El sistema empareja alumnos con perfiles complementarios para hacer un módulo juntos.

### Flujo:
1. Alumno activa "Buscar colega de aprendizaje" en su perfil
2. Sistema empareja según: mismo nivel del curso, diferente institución, diferente cargo
3. Ambos reciben notificación: "Te emparejamos con [nombre] de [institución]"
4. Tienen 7 días para completar el módulo asignado juntos
5. Al terminar: badge "Aprendí en equipo" para ambos
6. Chat privado entre los dos durante el módulo (simple: mensajes en Firestore)

### Modelo Firestore:
```
/learning_pairs/{pairId}:
  userA: userId, userB: userId
  moduleId: string
  status: "active" | "completed" | "expired"
  createdAt, completedAt
  
/learning_pairs/{pairId}/messages/{msgId}:
  userId, text, createdAt
```

### Archivos:
- components/community/FindColleague.tsx
- components/community/PairChat.tsx
- app/mi-colega/page.tsx
- lib/services/learningPairs.ts

---

## 5. Mentores de cohortes anteriores

Alumnos que completaron el programa pueden ser mentores voluntarios.

### Flujo:
1. Al obtener certificado: "¿Quieres ser mentor de la próxima cohorte?"
2. Si acepta: aparece en /mentores con foto, institución y cargo
3. Alumno actual puede solicitar 1 sesión de 30 min (formulario simple)
4. Admin aprueba o rechaza la solicitud
5. Coordinación por WhatsApp (campo guardado en perfil)

### Archivos:
- app/mentores/page.tsx
- components/community/MentorCard.tsx
- app/admin/mentores/page.tsx
- lib/services/mentors.ts

---

## 6. Red de egresados

Al certificarse, el alumno entra a una red permanente.

### Lo que incluye:
- Directorio de egresados: nombre, institución, cargo, cohorte, LinkedIn (opcional)
- Filtrar por institución, región, cohorte
- El bot conecta a personas con proyectos similares:
  "Vi que trabajas en gestión del cambio — hay 3 egresados con proyectos similares. ¿Te los presento?"
- Badge especial "Egresado Política Digital" para el perfil

### Archivos:
- app/egresados/page.tsx
- components/community/AlumniDirectory.tsx
- lib/services/alumni.ts

---

## Restricciones:
- En modo demo: mostrar datos ficticios, no guardar interacciones reales
- El chat de colega no es en tiempo real (polling cada 30s está bien)
- No mostrar información de contacto directa sin consentimiento
- Todas las funciones sociales son opt-in (el alumno elige participar)
