# Bloque 2 — Contenido moderno

Implementa un sistema de lecciones rico e interactivo en Política Digital.

---

## 1. Lecciones Notion-style (reemplazar formato actual)

El editor de lecciones debe soportar bloques de contenido rico:

### Tipos de bloques para el admin:
- **Texto** — párrafo normal con formato básico (bold, italic, links)
- **Encabezado** — H2 y H3
- **Callout** — caja destacada con ícono (💡 Tip, ⚠️ Importante, 📌 Recuerda)
- **Toggle** — sección colapsable (clic para revelar)
- **Imagen** — con caption
- **Video embed** — YouTube o Loom por URL
- **Separador** — línea divisoria visual
- **Cita** — blockquote estilizado
- **Lista** — bullets o numerada
- **Código** — bloque de código con syntax highlight
- **Checklist** — lista de verificación interactiva para el alumno

### Para el alumno:
- Los toggles se pueden abrir/cerrar
- Los checklists se pueden marcar (se guarda en Firestore)
- El video embed se reproduce inline
- Barra de progreso de lectura en la parte superior

### Implementación:
Usar la librería `@udecode/plate` o bloques personalizados con React.
Si plate es muy complejo, implementar los bloques manualmente como componentes React.

Guardar el contenido como JSON en Firestore: /lessons/{lessonId}/blocks: []

### Archivos:
- components/lesson/LessonContent.tsx — renderer de bloques
- components/lesson/blocks/ — un archivo por tipo de bloque
- components/admin/LessonEditor.tsx — editor drag & drop para admin
- lib/services/lessonBlocks.ts

---

## 2. H5P — Contenido interactivo embebido

Integrar H5P para contenido interactivo dentro de lecciones.

### Instalar:
```bash
npm install @lumieducation/h5p-react
```

### Tipos de H5P a soportar:
- **Interactive Video** — video con preguntas en momentos específicos
- **Flashcards** — tarjetas con frente y dorso
- **Drag and Drop** — arrastrar conceptos a categorías
- **Image Hotspot** — imagen con zonas clicables
- **Quiz H5P** — quiz básico con feedback inmediato

### Flujo:
1. Admin sube archivo .h5p o pega JSON en /admin/cursos/[id]/lecciones/[id]
2. El contenido H5P se guarda en Firebase Storage
3. En la lección del alumno, renderizar el H5PPlayer como un bloque más

### Archivos:
- components/lesson/H5PPlayer.tsx
- components/admin/H5PUploader.tsx
- lib/services/h5p.ts

---

## 3. Biblioteca de recursos por módulo

Cada módulo tiene una pestaña "Recursos" con material complementario.

### Tipos de recursos:
- PDF descargable (subido a Firebase Storage)
- Link externo (paper, artículo, video)
- Video de YouTube embebido
- Link a organismos: OCDE, BID, MinCiencia, CEPAL

### Para el admin:
- En /admin/cursos/[id]/módulos/[id]: sección "Agregar recursos"
- Campos: título, tipo, URL o archivo, descripción breve (opcional)

### Para el alumno:
- Pestaña "Recursos" en la vista del módulo
- Filtrar por tipo (videos, papers, links)
- Marcar como "leído/visto" (guarda en Firestore)
- Contador: "3 de 5 recursos revisados"

### Archivos:
- components/learning/ResourceLibrary.tsx
- components/admin/ResourceManager.tsx
- app/curso/modulos/[moduleId]/recursos/page.tsx
- lib/services/resources.ts

---

## 4. Glosario colaborativo

Términos clave definidos y votados por los propios alumnos.

### Flujo:
1. Admin define lista de términos por curso en /admin/glosario
2. Alumno puede proponer una definición para cada término
3. Otros alumnos votan la mejor definición (👍 / 👎)
4. La definición más votada se muestra como "definición oficial de la cohorte"
5. Historial de todas las definiciones propuestas

### Modelo Firestore:
```
/glossary/{courseId}/terms/{termId}:
  term: string
  officialDefinition: string (dada por admin)
  
/glossary/{courseId}/terms/{termId}/proposals/{proposalId}:
  userId: string
  definition: string
  votes: number
  createdAt: Timestamp
```

### Archivos:
- app/glosario/page.tsx
- components/glossary/GlossaryTerm.tsx
- components/glossary/ProposalForm.tsx
- lib/services/glossary.ts

---

## 5. Bot bibliográfico

Al terminar una lección, el bot ofrece: "¿Quieres profundizar en este tema?"

Si el alumno dice sí, el bot sugiere:
- 1 libro relacionado
- 1 paper o informe técnico
- 1 caso práctico del sector público latinoamericano

Implementación:
- Usar Claude API con un prompt específico:
  "Eres un asistente académico especializado en innovación pública latinoamericana. 
   El alumno acaba de terminar la lección sobre [lessonName]. 
   Sugiere: 1 libro real, 1 paper/informe real de OCDE/BID/CEPAL, 1 caso práctico real.
   Formato JSON: { book: {title, author, year}, paper: {title, org, url}, case: {title, country, description} }"
- Mostrar las sugerencias en cards dentro del chat del bot

### Archivos:
- Actualizar system prompt del bot en app/api/assistant/route.ts
- components/assistant/BibliographyCard.tsx

---

## Restricciones:
- En modo demo: mostrar contenido de ejemplo
- El editor de lecciones es solo para admin
- Los bloques Notion-style son backward compatible con lecciones existentes
- No borrar el contenido de texto simple actual — migrarlo a bloque de tipo "texto"
